package domain.card;

public enum CardColor {
    RED,
    GREEN,
    BLUE,
    YELLOW
}
