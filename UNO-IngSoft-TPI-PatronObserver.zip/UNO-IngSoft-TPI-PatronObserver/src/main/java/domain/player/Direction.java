package domain.player;

public enum Direction {
    CLOCKWISE,
    COUNTER_CLOCK_WISE
}
